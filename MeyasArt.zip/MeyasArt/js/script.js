document.getElementById("clickText").addEventListener("click", function() {
      var overlay = document.getElementById("overlay");
      overlay.style.backgroundColor = "rgba(0, 0, 0, 0.7)";
  });
  